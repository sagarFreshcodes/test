import React from "react";
import MainPage from "./CRUD/mainPage";

function Home() {
  return (
    <>
      <MainPage />
    </>
  );
}

export default Home;
