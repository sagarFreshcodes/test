import React from "react";
import Table from "./Table/Table";

const MainPage = () => {
  return (
    <div>
      <Table />
    </div>
  );
};

export default MainPage;
